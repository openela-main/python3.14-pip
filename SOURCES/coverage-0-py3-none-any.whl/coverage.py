def process_startup():
    pass
